
public class CustomerList {

	public void addCustomer() {
		
	}
	
	public void deleteCustomer() {
		
	}
	
	public void findCustomerId() {
		
	}
	
	public void findCustomerName() {
		
	}
	
	public void listByCustomerId() {
		
	}
	
	public void listByCustomerCategory() {
		
	}
}
