
public class OrderList {

	public void addOrder() {
		
	}
	
	public void deleteOrder() {
		
	}
	
	public void findOrderId() {
		
	}
	
	public void findOrderNames() {
		
	}
	
	public void listByOrderId() {
		
	}
	
	public void listByOrderTimestamp() {
		
	}
	
	/** method giving the sales of the day
	programmed so it gets out at a specific time of the day (for now)
	if we have time add the option to command it **/
	public void endOfTheDay() {
		
	}
}
